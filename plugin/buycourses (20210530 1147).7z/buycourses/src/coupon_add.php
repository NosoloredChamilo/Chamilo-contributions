<?php
/* For license terms, see /license.txt */

/**
 * Configuration script for the Buy Courses plugin.
 *
 * @package chamilo.plugin.buycourses
 */

require_once '../config.php';

api_protect_admin_script();

$plugin = BuyCoursesPlugin::create();

$includeSession = $plugin->get('include_sessions') === 'true';
$includeServices = $plugin->get('include_services') === 'true';


$entityManager = Database::getManager();
$userRepo = UserManager::getRepository();
$currency = $plugin->getSelectedCurrency();

if (empty($currency)) {
    Display::addFlash(
        Display::return_message($plugin->get_lang('CurrencyIsNotConfigured'), 'error')
    );
}

$currencyIso = null;

/* inicio  jcp */

$courses = CourseManager::get_courses_list(
    0,
    0,
    'title',
    'asc',
    -1,
    null,
    api_get_current_access_url_id(),
    false,
    [],
    []
);

$sessions = SessionManager::get_sessions_list(
    [],
    [],
    0,
    0,
    -1,
    api_get_current_access_url_id(),
    []
);

$services = $plugin->getServices(0, 0);

$discountTypes = $plugin->getCouponDiscountTypes();

// Build the form
$form = new FormValidator('add_coupon');
$form->addText('code', $plugin->get_lang('CouponCode'), true);
$form->addHtml(
    Display::return_message(
        $plugin->get_lang('PleaseSelectTheCouponDiscountType'),
        'info'
    )
);
$form->addRadio('discount_type', null, $discountTypes);
$form->addElement(
    'number',
    'discount_amount',
    [$plugin->get_lang('CouponDiscountAmount'), null, $currencyIso],
    ['step' => 1]
);
$form->addDateRangePicker('date', get_lang('Date'), true);
$button = $form->addButtonSave(get_lang('Save'));

if (empty($currency)) {
    $button->setAttribute('disabled');
}

if ($form->validate()) {
    $formValues = $form->exportValues();

    $coupon['code'] = $formValues['code'];
    $coupon['discount_type'] = $formValues['discount_type'];
    $coupon['discount_amount'] = $formValues['discount_amount'];
    $coupon['valid_start'] = $formValues['range_start'];
    $coupon['valid_end'] = $formValues['range_end'];

    if ($coupon['discount_type'] == BuyCoursesPlugin::COUPON_DISCOUNT_TYPE_PERCENTAGE && $coupon['discount_amount'] > 100){
        Display::addFlash(
            Display::return_message($plugin->get_lang('CouponDiscountExceed100'), 'error', false)
        );
        header('Location:'.api_get_self().'?'.$queryString);
        exit;
    }

    $plugin->addNewCoupon($coupon);

    header('Location: '.api_get_path(WEB_PLUGIN_PATH).'buycourses/src/list_coupon.php');
    exit;
}

$form->setDefaults($formDefaults);

$templateName = $plugin->get_lang('CouponAdd');
$interbreadcrumb[] = [
    'url' => 'paymentsetup.php',
    'name' => get_lang('Configuration'),
];
$interbreadcrumb[] = [
    'url' => 'coupon_add.php',
    'name' => $plugin->get_lang('CouponAdd'),
];

$template = new Template($templateName);
$template->assign('header', $templateName);
$template->assign('content', $form->returnForm());
$template->display_one_col_template();
