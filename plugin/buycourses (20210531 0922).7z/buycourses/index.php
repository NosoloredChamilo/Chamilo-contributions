<?php
/* For license terms, see /license.txt */
/**
 * Show form.
 */
require_once 'config.php';
require_once 'src/index.buycourses.php';
