<?php
// Redirect to buycourses/index.php
header('location: index.php');
